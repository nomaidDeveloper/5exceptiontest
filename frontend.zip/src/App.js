import React from "react";
import { createBrowserRouter, RouterProvider } from "react-router-dom";
import GetItem from "./components/GetItems";
import CreateItem from "./components/CreateItem";
import 'bootstrap/dist/css/bootstrap.min.css';

const router = createBrowserRouter([
  {
    path: "/",
    element: <CreateItem />,
  },
  {
    path: "/list",
    element: <GetItem />,
  },
]);
function App() {
  return (
    <div className="App">
      <RouterProvider router={router} />
    </div>
  );
}

export default App;
