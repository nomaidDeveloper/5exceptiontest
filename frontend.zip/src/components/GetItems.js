import React, { useState, useEffect, memo } from 'react';
import { Container, Table, Pagination, Alert, Button } from 'react-bootstrap';
import axios from 'axios';

const ItemTable = memo(({ items }) => (
  <Table striped bordered hover>
    <thead>
      <tr>
        <th>Image</th>
        <th>Title</th>
        <th>Description</th>
        <th>Qty</th>
        <th>Price</th>
        <th>Date</th>
      </tr>
    </thead>
    <tbody>
      {items.length ? (
        items.map(item => (
          <tr key={item.id}>
            <td>
              {item.image ? (
                <img
                  src={`http://localhost:8000/uploads/${item.image}`}
                  alt={item.title}
                  style={{ width: '50px', height: '50px' }}
                />
              ) : (
                'No image'
              )}
            </td>
            <td>{item.title}</td>
            <td>{item.description}</td>
            <td>{item.qty}</td>
            <td>{item.price}</td>
            <td>{new Date(item.date).toLocaleDateString()}</td>
          </tr>
        ))
      ) : (
        <tr>
          <td colSpan="6" className="text-center">No items found</td>
        </tr>
      )}
    </tbody>
  </Table>
));

const PaginationComponent = memo(({ currentPage, totalPages, onPageChange }) => (
  <Pagination className="mt-3">
    <Pagination.Prev
      onClick={() => currentPage > 1 && onPageChange(currentPage - 1)}
      disabled={currentPage === 1}
    />
    {[...Array(totalPages)].map((_, index) => (
      <Pagination.Item
        key={index + 1}
        active={index + 1 === currentPage}
        onClick={() => onPageChange(index + 1)}
      >
        {index + 1}
      </Pagination.Item>
    ))}
    <Pagination.Next
      onClick={() => currentPage < totalPages && onPageChange(currentPage + 1)}
      disabled={currentPage === totalPages}
    />
  </Pagination>
));

const GetItem = () => {
  const [items, setItems] = useState([]);
  const [title, setTitle] = useState('');
  const [startDate, setStartDate] = useState('');
  const [endDate, setEndDate] = useState('');
  const [currentPage, setCurrentPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [error, setError] = useState('');

  useEffect(() => {
    const fetchItems = async () => {
      try {
        const response = await axios.get('http://localhost:8000/items', {
          params: { page: currentPage, title, startDate, endDate },
        });
        setItems(response.data.items);
        setTotalPages(response.data.totalPages);
        setError('');
      } catch (error) {
        setError('Error fetching items. Please try again later.');
      }
    };

    fetchItems();
  }, [title, startDate, endDate, currentPage]);

  const handlePageChange = (page) => {
    setCurrentPage(page);
  };

  return (
    <Container>
      <h2>Item List</h2>
      <div className="mb-3">
        <Button variant="outline-primary" href='/'>Create Item</Button>
      </div>
      {error && <Alert variant="danger">{error}</Alert>}
      <ItemTable items={items} />
      <PaginationComponent
        currentPage={currentPage}
        totalPages={totalPages}
        onPageChange={handlePageChange}
      />
    </Container>
  );
};

export default GetItem;
