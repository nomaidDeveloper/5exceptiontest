import React, { useState } from 'react';
import { Form, Button, Container, Row, Col } from 'react-bootstrap';
import axios from 'axios';
import { toast, ToastContainer } from 'react-toastify';
import 'react-toastify/dist/ReactToastify.css';


const CreateItem = () => {
    const [items, setItems] = useState([{ title: '', description: '', qty: '', price: '', date: '', image: '' }]);

    const handleChange = (index, event) => {
        const { name, value } = event.target;
        const newItems = [...items];
        newItems[index][name] = value;
        setItems(newItems);
    };

    const handleImageChange = (index, event) => {
        const file = event.target.files[0];
        const newItems = [...items];
        newItems[index].image = file;
        setItems(newItems);
    };

    const addItem = () => {
        setItems([...items, { title: '', description: '', qty: '', price: '', date: '', image: '' }]);
    };

    const removeItem = (index) => {
        const newItems = items.filter((_, i) => i !== index);
        setItems(newItems);
    };

    const handleSubmit = async (event) => {
        event.preventDefault();
        for (const item of items) {
            if (!item.title.trim() || !item.qty.trim() || !item.price.trim()) {
                toast.error('Title, quantity, and price must not be blank.');
                return;
            }
        }

        const formData = new FormData();
        formData.append('items', JSON.stringify(items.map(item => ({
            title: item.title,
            description: item.description,
            qty: item.qty,
            price: item.price,
            date: item.date
        }))));
        
        items.forEach((item, index) => {
            if (item.image) {
                formData.append('images', item.image);
            }
        });

        try {
            await axios.post('http://localhost:8000/items', formData, {
                headers: {
                    'Content-Type': 'multipart/form-data'
                }
            });
            toast.success('Items created successfully!');
            setItems([{ title: '', description: '', qty: '', price: '', date: '', image: '' }]);
        } catch (error) {
            console.error('Error creating items:', error);
            toast.error('Error creating items');
        }
    };

    return (
        <Container>
            <div className="mb-3">
                <Button variant="outline-primary" href='/list'>All Item List</Button>
            </div>
            <h2>Adding Items</h2>
            <Form onSubmit={handleSubmit}>
                {items.map((item, index) => (
                    <Row key={index} className="mb-3 align-items-center">
                        <Col md={2}>
                            <Form.Control type="file" onChange={(e) => handleImageChange(index, e)} />
                        </Col>
                        <Col>
                            <Form.Control name="title" value={item.title} onChange={(e) => handleChange(index, e)} placeholder="Title" />
                        </Col>
                        <Col>
                            <Form.Control name="description" value={item.description} onChange={(e) => handleChange(index, e)} placeholder="Description" />
                        </Col>
                        <Col md={1}>
                            <Form.Control name="qty" value={item.qty} onChange={(e) => handleChange(index, e)} placeholder="Qty" />
                        </Col>
                        <Col md={2}>
                            <Form.Control name="price" value={item.price} onChange={(e) => handleChange(index, e)} placeholder="Price" />
                        </Col>
                        <Col md={2}>
                            <Form.Control name="date" type="date" value={item.date} onChange={(e) => handleChange(index, e)} />
                        </Col>
                        <Col md={1}>
                            <Button variant="outline-danger" onClick={() => removeItem(index)}>-</Button>
                        </Col>
                    </Row>
                ))}
                <Button variant="outline-primary" onClick={addItem} className="mb-3">+</Button>
                <div>
                    <Button type="submit">Save</Button>
                </div>
            </Form>
            <ToastContainer />
        </Container>
    );
};

export default CreateItem;