const sequelize = require('../config/db');
const Item = require('./ItemModel');

const db = {};
db.Sequelize = sequelize;
db.Item = Item;

db.sync = async () => {
  try {
    await sequelize.sync();
    console.log("Database synced successfully.");
  } catch (error) {
    console.error("Error syncing database:", error);
  }
};

module.exports = db;