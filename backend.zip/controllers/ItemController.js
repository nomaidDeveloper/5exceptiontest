const db = require('../models');
const multer = require('multer');
const path = require('path');

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + path.extname(file.originalname));
    }
});

const upload = multer({ storage }).array('images');

exports.createItem = (req, res) => {
    upload(req, res, async (err) => {
        if (err) {
            return res.status(500).json({ error: err.message });
        }

        try {
            const items = JSON.parse(req.body.items).map((item, index) => {
                const { title, description, qty, price, date } = item;
                const image = req.files && req.files[index] ? req.files[index].filename : null;
                return { title, description, qty, price, date, image };
            });

            const createdItems = await db.Item.bulkCreate(items);
            res.status(201).json({ items: createdItems });
        } catch (error) {
            console.error('Error creating items:', error);
            res.status(500).json({ error: error.message });
        }
    });
};


exports.getItems = async (req, res) => {
    const { page = 1, limit = 2, title, startDate, endDate } = req.query;
    const offset = (page - 1) * limit;

    let where = {};
    if (title) where.title = { [db.Sequelize.Op.like]: `%${title}%` };
    if (startDate && endDate) where.date = { [db.Sequelize.Op.between]: [startDate, endDate] };

    try {
        const { count, rows } = await db.Item.findAndCountAll({
            where,
            limit: parseInt(limit),
            offset: parseInt(offset),
            order: [['date', 'DESC']]
        });

        res.status(200).json({
            totalItems: count,
            totalPages: Math.ceil(count / limit),
            currentPage: parseInt(page),
            items: rows
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};
